<div id="loggingin">
<h1>Processing Login</h1>
<progress></progress>
<p>If you see this for more than 5 seconds, <a id="exit" href="accountentry.php">click here</a>
</p>
</div>