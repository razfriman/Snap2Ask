<form action="processsgnup.php" method='post'>
<input autocomplete="on" autofocus="true" class="input" id="email" name="email" placeholder="E-mail
Address" type="text" /><label class="hidelabel" for="pass">Password </label>
<input id="pass" maxlength="64" name="pass" placeholder="Password" type="password" name="pass" value="" />
<input class="sgnup" id="sgnUp" name="sgnUp" title="sgnup" type="submit" value="Sign Up" />
        				<div><input checked="checked" id="remember_me" name="keepMeSignInOption" type="checkbox" value="1" /><label for="remember_me">Remember&nbsp;me</label>&nbsp;</div>
                        </form>