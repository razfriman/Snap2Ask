
<table border="1">
<tbody>
<tr>
<td >Your Account<br>
<table border="1">
<tbody>
<tr>
<td> Total Earnings: </td>
<td> $0.00 </td>
</tr>
<tr>
<td> Total Feedback: </td>
<td> 100<br>
</td>
</tr>
<tr>
<td >Total Answers Approved:<br>
</td>
<td >120<br>
</td>
</tr>
<tr>
<td >Total Answers Denied:<br>
</td>
<td >20<br>
</td>
</tr>
<tr>
<td >Total Questions Answered<br>
</td>
<td >140<br>
</td>
</tr>
</tbody>
</table>
View Feedback Profile<br>
View Answered Questions<br>
View Invoices<br>
Take a Test<br>
View Suggested Questions<br>
<br>
</td>
<td >
<table border="1" cellpadding="2" cellspacing="2"
width="100%">
<tbody>
<tr>
<td ><br>
</td>
</tr>
<tr>
<td >Questions I Answered<br>
</td>
</tr>
<tr>
<td ><br>
</td>
</tr>
<tr>
<td ><br>
</td>
</tr>
<tr>
<td ><br>
</td>
</tr>
<tr>
<td ><br>
</td>
</tr>
<tr>
<td ><br>
</td>
</tr>
<tr>
<td ><br>
</td>
</tr>
<tr>
<td ><br>
</td>
</tr>
<tr>
<td ><br>
</td>
</tr>
<tr>
<td ><br>
</td>
</tr>
<tr>
<td ><br>
</td>
</tr>
<tr>
<td ><br>
</td>
</tr>
<tr>
<td ><br>
</td>
</tr>
<tr>
<td ><br>
</td>
</tr>
<tr>
<td ><br>
</td>
</tr>
<tr>
<td ><br>
</td>
</tr>
<tr>
<td ><br>
</td>
</tr>
<tr>
<td ><br>
</td>
</tr>
<tr>
<td ><br>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>


