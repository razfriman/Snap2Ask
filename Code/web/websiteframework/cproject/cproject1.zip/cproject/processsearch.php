<?php
    $xview= "results";
    include("index.php");
?>