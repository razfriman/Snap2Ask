<?php
include("helloname.php");
    $xview= "account";
include("index.php");
?>