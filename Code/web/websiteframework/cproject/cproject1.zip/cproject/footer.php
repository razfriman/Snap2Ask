<table border="1">
    <tbody>
		<tr>
			<td>Site Info
			<div>
			<ul>
				<li><a class="footerlink" href="file:///C:/Documents%20and%20Settings/Student/My%20Documents/Snap%202%20Ask%20Home%20Page.html#" id="ctl00_DemoVideoLink" target="_blank">Terms of Use</a></li>
				<li><a class="footerlink" href="file:///C:/Documents%20and%20Settings/Student/My%20Documents/Snap%202%20Ask%20Home%20Page.html#" id="ctl00_DemoVideoLink" target="_blank">Privacy Policy</a></li>
				<li><a class="footerlink" href="file:///C:/Documents%20and%20Settings/Student/My%20Documents/Snap%202%20Ask%20Home%20Page.html#" id="ctl00_DemoVideoLink" target="_blank">Frequently Asked Questions</a></li>
				<li style=""><a class="footerlink" href="file:///C:/Documents%20and%20Settings/Student/My%20Documents/Snap%202%20Ask%20Home%20Page.html#" id="ctl00_DemoVideoLink">Demo Video</a></li>
			</ul>
			<span class="subtext">&copy; 2013 Homework Help Group. All rights reserved.</span></div>
			</td>
			<td>
			<div id="ctl00_mobile_app">
			<div class="mainbox-copy-header">Download the Snap2Ask App for Android&trade;</div>

			<div style="margin-top: 15px;"><a href="file:///C:/Documents%20and%20Settings/Student/My%20Documents/Snap%202%20Ask%20Home%20Page.html#"><img alt="Tutor.com To Go - Learn More" src="http://lhh.tutor.com/lhh/images/iphone-btn.png" style="float:left;margin-right: 15px;" /></a>

			<div>Snap2Ask To Go&trade; is the free mobile companion for any Android cell phone or tablet. Connect to get homework help instantly, review past sessions, or upload your photos for our tutors to answer. <a href="file:///C:/Documents%20and%20Settings/Student/My%20Documents/Snap%202%20Ask%20Home%20Page.html#">Learn More</a>.</div>
			</div>
			</div>
			</td>
		</tr>
	</tbody>
</table>
</html>