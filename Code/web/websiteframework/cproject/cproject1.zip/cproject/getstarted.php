<h2 id="intro">Get paid to answer questions TODAY!</h2>
<p><a href="register.php">Register Now</a>Already have an account?  Login Now</p>
<?php include("form.php")?>